/**
 * @file student.h
 * @author Tom Overall
 * @brief Student library header file
 * @version 1.0
 * @date 2022-04-12
 * 
 */

/**
 * @brief Student struct that contains a student's first name, last name, student ID, and list of their grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50];  /**< student's first name*/
  char last_name[50];   /**< student's last name*/
  char id[11];          /**< student's student ID*/
  double *grades;       /**< student's grade as a double*/
  int num_grades;       /**< student's amount of grades*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
