/**
 * @file main.c
 * @author Tom Overall
 * @brief Main file that demonstrates various libraries
 * @version 1.0
 * @date 2022-04-12
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  
  //Sets random seed for random generator 
  srand((unsigned) time(NULL));

  
  //Initilizaing MATH101 course by allocating it to the heap
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Generating 20 random students and enrolling them into MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Declaring a student pointer
  Student *student;
  //Finds the top student in MATH101 and prints them.
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Holds the number of students that have passed MATH101
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //Iterates through the passing students and prints them out
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}