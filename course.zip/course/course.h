/**
 * @file course.h
 * @author Tom Overall
 * @brief Course library header file
 * @version 1.0
 * @date 2022-04-12
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Course struct. Contains the course's name, code, a list of students, and the total number of students enrolled
 * 
 */
typedef struct _course 
{
  char name[100];       /**< course name*/
  char code[10];        /**< course code*/
  Student *students;    /**< course list of students enrolled in course*/
  int total_students;   /**< total number of students enrolled in the course*/
} Course;

//Methods for enrolling students and printing the courses
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


